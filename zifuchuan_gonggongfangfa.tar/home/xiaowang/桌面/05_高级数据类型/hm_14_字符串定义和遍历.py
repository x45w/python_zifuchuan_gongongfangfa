str1 = "hello python"
str2 = 'hello python'
str3 = '我的外号是"大西瓜"'
str4 = "我的外号是'大西瓜'"

print(str1)
print(str2)
print(str3)
print(str4)
print(str1[6])

for char in str3:
    print(char)