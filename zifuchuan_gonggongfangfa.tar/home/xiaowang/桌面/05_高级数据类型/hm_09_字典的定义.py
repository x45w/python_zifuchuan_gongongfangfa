# 字典是一个无序的数据集合,使用print函数输出字典时,通常
# 输出的顺序和定义的顺序是不一致的
xiaoming = {"name":"小明",
            "age":18,
            "gender":True,
            "weight":75.5}

print(xiaoming)